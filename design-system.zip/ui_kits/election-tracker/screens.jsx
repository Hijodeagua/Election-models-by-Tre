// Election Oracle UI Kit — the five tracker screens
const {
  EO_T: S, PageHead, Panel, StatCard, MetaStrip, Pill,
  ApprovalChart, BallotChart, SeatBar, ForecastHistogram, ProbSplit, Sparkline,
} = window;

const grid3 = { display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 12, marginBottom: 16 };

// ── 1 · APPROVAL ─────────────────────────────────────────────────────────────
function ApprovalScreen() {
  return (
    <div>
      <PageHead kicker="Presidential Approval" title="Is the country buying what the President is selling?"
        sub="A weighted average of every public job-approval poll, smoothed with a state-space model that down-weights cheap online surveys and corrects for house effects." />
      <div style={grid3}>
        <StatCard label="Approve" value="40.3%" tone="dem" sub="[38.8 – 41.4]" />
        <StatCard label="Disapprove" value="52.1%" tone="rep" sub="[50.5 – 53.6]" />
        <StatCard label="Net approval" value="−11.8" tone="ink" sub="lowest since inauguration" />
      </div>
      <MetaStrip items={[{ k: 'Updated', v: 'May 24, 2026' }, { k: 'Polls in window', v: '683' }, { k: 'Model', v: 'state-space avg' }]} />
      <Panel title="Daily polling average · confidence band"
        legend={[{ label: 'Approve', color: S.dem }, { label: 'Disapprove', color: S.rep }]} style={{ marginBottom: 14 }}>
        <ApprovalChart />
      </Panel>
      <Panel title="The one-line read">
        <p style={{ fontFamily: S.serif, fontSize: 19, color: S.ink, lineHeight: 1.4, margin: 0 }}>
          Approval has drifted down about five points over the past year and has been flat-to-soft since winter — <span style={{ color: S.peach }}>underwater by double digits</span>, but not collapsing.
        </p>
      </Panel>
    </div>
  );
}

// ── 2 · GENERIC BALLOT ───────────────────────────────────────────────────────
function BallotScreen() {
  return (
    <div>
      <PageHead kicker="Generic Congressional Ballot" title="Which party do voters want running Congress?"
        sub="“If the election were held today, would you vote for the Democrat or the Republican in your district?” — averaged and translated into a rough seat estimate." />
      <div style={grid3}>
        <StatCard label="Democrats" value="46.4%" tone="dem" />
        <StatCard label="Republicans" value="41.1%" tone="rep" />
        <StatCard label="Democratic edge" value="D+5.3" tone="peach" />
      </div>
      <div style={{ display: 'grid', gridTemplateColumns: '3fr 2fr', gap: 14 }}>
        <Panel title="Generic ballot margin over time" style={{ marginBottom: 0 }}>
          <BallotChart />
        </Panel>
        <Panel title="Illustrative House seat split" style={{ marginBottom: 0 }}>
          <div style={{ display: 'flex', gap: 18, marginBottom: 18 }}>
            <div><div style={{ fontFamily: S.serif, fontSize: 38, color: S.dem, lineHeight: 1 }}>247</div><div style={{ fontSize: 11, color: S.cocoa500, fontFamily: S.sans }}>Democratic</div></div>
            <div><div style={{ fontFamily: S.serif, fontSize: 38, color: S.rep, lineHeight: 1 }}>188</div><div style={{ fontSize: 11, color: S.cocoa500, fontFamily: S.sans }}>Republican</div></div>
          </div>
          <SeatBar dem={247} rep={188} />
          <p style={{ fontSize: 11, color: S.cocoa400, fontFamily: S.sans, marginTop: 12, lineHeight: 1.5 }}>
            A national-swing estimate, <em>not</em> a district-by-district forecast. Real seats hinge on incumbency and maps.
          </p>
        </Panel>
      </div>
    </div>
  );
}

// ── 3 · SENATE ───────────────────────────────────────────────────────────────
function SenateRaceRow({ race }) {
  const [vibes, setVibes] = React.useState(false);
  const m = vibes && race.vibes ? race.margin + race.vibesShift : race.margin;
  const lead = m > 0 ? 'D' : 'R';
  const leadColor = m > 0 ? S.dem : S.rep;
  return (
    <div style={{ background: S.surface, border: `1px solid ${S.border}`, borderRadius: 12, padding: 16, display: 'flex', alignItems: 'center', gap: 16 }}>
      <div style={{ minWidth: 86 }}>
        <div style={{ fontFamily: S.serif, fontSize: 19, color: S.ink, lineHeight: 1 }}>{race.state}</div>
        <div style={{ fontSize: 10.5, color: S.cocoa400, fontFamily: S.sans, marginTop: 3 }}>{race.numPolls} polls</div>
      </div>
      <div style={{ flex: 1 }}>
        <div style={{ fontSize: 13, color: S.cocoa700, fontFamily: S.sans }}>
          {race.cands[0].n} <strong style={{ color: S.dem }}>{race.cands[0].p}%</strong>
          <span style={{ color: S.cocoa300, margin: '0 8px' }}>·</span>
          {race.cands[1].n} <strong style={{ color: S.rep }}>{race.cands[1].p}%</strong>
        </div>
        <div style={{ display: 'flex', gap: 6, marginTop: 8 }}>
          {race.vibes && <Pill onClick={() => setVibes(!vibes)} active={vibes} tone="neutral">NYT vibes {vibes ? 'on' : 'off'}</Pill>}
          <Pill tone="neutral">Polymarket {lead} {race.market}%</Pill>
        </div>
      </div>
      <Sparkline data={race.spark} color={leadColor} />
      <div style={{ textAlign: 'right', minWidth: 70 }}>
        <div style={{ fontFamily: S.serif, fontSize: 24, color: leadColor, lineHeight: 1 }}>{lead}+{Math.abs(m).toFixed(1)}</div>
        <div style={{ fontSize: 10, color: S.cocoa400, fontFamily: S.sans, marginTop: 3 }}>{vibes && race.vibes ? 'with vibes' : 'base model'}</div>
      </div>
    </div>
  );
}

function SenateScreen() {
  const races = [
    { state: 'Arizona', cands: [{ n: 'Gallego', p: 48.2 }, { n: 'Lake', p: 44.8 }], margin: 3.4, vibesShift: 1.2, vibes: true, numPolls: 8, market: 61, spark: [1.1, 1.8, 2.4, 2.9, 3.1, 3.4] },
    { state: 'Georgia', cands: [{ n: 'Warnock', p: 47.1 }, { n: 'Kemp', p: 46.1 }], margin: 1.0, vibesShift: 0.8, vibes: true, numPolls: 12, market: 54, spark: [2.0, 1.6, 1.2, 0.9, 1.1, 1.0] },
    { state: 'Michigan', cands: [{ n: 'Peters', p: 49.5 }, { n: 'Rogers', p: 46.5 }], margin: 3.0, vibesShift: 0, vibes: false, numPolls: 10, market: 67, spark: [2.2, 2.6, 2.8, 3.1, 2.9, 3.0] },
    { state: 'Pennsylvania', cands: [{ n: 'McCormick', p: 47.9 }, { n: 'Deluzio', p: 46.4 }], margin: -1.5, vibesShift: 0.9, vibes: true, numPolls: 14, market: 44, spark: [-0.4, -0.8, -1.0, -1.3, -1.4, -1.5] },
    { state: 'Nevada', cands: [{ n: 'Rosen', p: 48.0 }, { n: 'Brown', p: 46.2 }], margin: 1.8, vibesShift: 0, vibes: false, numPolls: 7, market: 58, spark: [1.2, 1.5, 1.7, 1.6, 1.9, 1.8] },
    { state: 'Ohio', cands: [{ n: 'Brown', p: 47.4 }, { n: 'Moreno', p: 47.0 }], margin: 0.4, vibesShift: 1.1, vibes: true, numPolls: 9, market: 49, spark: [-0.6, -0.2, 0.1, 0.3, 0.5, 0.4] },
  ];
  return (
    <div>
      <PageHead kicker="Senate Battlegrounds" title="The six races that decide the chamber"
        sub="Polling averages for the closest seats, with an optional “NYT vibes” fundamentals nudge and the latest prediction-market price for context." />
      <MetaStrip items={[{ k: 'Toss-ups', v: '6 of 34' }, { k: 'Most polled', v: 'Pennsylvania' }, { k: 'Tightest', v: 'Ohio (D+0.4)' }]} />
      <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
        {races.map(r => <SenateRaceRow key={r.state} race={r} />)}
      </div>
      <p style={{ fontSize: 11.5, color: S.cocoa400, fontFamily: S.sans, marginTop: 14, lineHeight: 1.5 }}>
        “NYT vibes” blends a light fundamentals adjustment (incumbency, state lean) into the raw average — toggle it to see how much the narrative is doing the work.
      </p>
    </div>
  );
}

// ── 4 · SENATE FORECAST ──────────────────────────────────────────────────────
function ForecastScreen() {
  return (
    <div>
      <PageHead kicker="Senate Forecast" title="Who controls the Senate after November?"
        sub="Ten thousand simulated elections, seeding each race with its polling average, correlated polling error, and a prediction-market prior." />
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12, marginBottom: 14 }}>
        <StatCard label="Democrats hold control" value="78%" tone="dem" sub="up 4 pts this week" />
        <StatCard label="Most likely outcome" value="D 52 · R 48" tone="ink" sub="modal simulated chamber" />
      </div>
      <Panel title="Chamber control probability" style={{ marginBottom: 14 }}>
        <ProbSplit demPct={78} />
      </Panel>
      <Panel title="Distribution of simulated outcomes" style={{ marginBottom: 14 }}>
        <ForecastHistogram />
      </Panel>
      <Panel title="Tipping-point races · ranked by leverage">
        <div style={{ display: 'flex', flexDirection: 'column', gap: 0 }}>
          {[
            { s: 'Ohio', m: 'D+0.4', p: 49, w: 22 },
            { s: 'Pennsylvania', m: 'R+1.5', p: 44, w: 19 },
            { s: 'Georgia', m: 'D+1.0', p: 54, w: 17 },
            { s: 'Nevada', m: 'D+1.8', p: 58, w: 14 },
            { s: 'Arizona', m: 'D+3.4', p: 61, w: 11 },
          ].map((r, i) => (
            <div key={r.s} style={{ display: 'flex', alignItems: 'center', gap: 12, padding: '9px 0', borderTop: i ? `1px solid ${S.border}` : 'none' }}>
              <span style={{ fontSize: 13, color: S.cocoa700, fontFamily: S.sans, minWidth: 110, fontWeight: 500 }}>{r.s}</span>
              <span style={{ fontSize: 12.5, color: S.cocoa500, fontFamily: S.sans, minWidth: 50 }}>{r.m}</span>
              <div style={{ flex: 1, height: 8, background: S.sunken, borderRadius: 4, overflow: 'hidden' }}>
                <div style={{ width: `${r.w * 4}%`, height: '100%', background: S.peach, borderRadius: 4 }}></div>
              </div>
              <span style={{ fontSize: 11.5, color: S.cocoa400, fontFamily: S.sans, minWidth: 78, textAlign: 'right' }}>{r.w}% tipping</span>
            </div>
          ))}
        </div>
      </Panel>
    </div>
  );
}

// ── 5 · METHODOLOGY ──────────────────────────────────────────────────────────
function MethodologyScreen() {
  const P = ({ children }) => <p style={{ fontSize: 16, lineHeight: 1.7, color: S.cocoa700, fontFamily: S.serifBody || "'Source Serif 4', Georgia, serif", margin: '0 0 18px' }}>{children}</p>;
  const H = ({ children }) => <h3 style={{ fontFamily: S.serif, fontSize: 22, color: S.ink, margin: '28px 0 10px' }}>{children}</h3>;
  return (
    <div style={{ maxWidth: 660 }}>
      <PageHead kicker="Methodology" title="How the Oracle actually works"
        sub="No black boxes. Here is every step between a raw poll and the numbers on this site." />
      <div style={{ background: S.peachWash, border: `1px solid ${S.peachBorder}`, borderRadius: 12, padding: '14px 18px', marginBottom: 24 }}>
        <p style={{ fontFamily: S.serif, fontSize: 17, color: S.peach, margin: 0, lineHeight: 1.4 }}>
          This is a <em>tracker</em>, not a crystal ball. We tell you where opinion is — not who will win your group chat's bet.
        </p>
      </div>
      <H>1 · Collecting the polls</H>
      <P>We ingest every public poll that releases a topline and crosstabs, logging the pollster, sample, mode, and field dates. Partisan-sponsored releases are kept but flagged so the model can discount them.</P>
      <H>2 · Weighting</H>
      <P>Each poll's influence scales with sample size, recency, and a pollster-quality score. Cheap online panels with thin track records get down-weighted; gold-standard live-caller surveys carry more.</P>
      <H>3 · The state-space average</H>
      <P>Rather than a blunt rolling mean, we fit a state-space model that treats true opinion as a slow-moving latent series and each poll as a noisy reading of it. That's what produces the smooth line and its confidence band.</P>
      <H>4 · House effects &amp; “vibes”</H>
      <P>We estimate each pollster's persistent lean and correct for it. On Senate races you can layer in a light fundamentals nudge — incumbency and state partisanship — that we cheekily call “NYT vibes.” It's optional, and we show you exactly how much it moves the number.</P>
      <H>5 · Markets as a sanity check</H>
      <P>Prediction-market prices (Polymarket, Kalshi) sit alongside the model as a gut-check — never baked silently into the average. When the model and the market disagree, that gap is usually the interesting part.</P>
      <div style={{ borderTop: `1px solid ${S.border}`, marginTop: 28, paddingTop: 16, fontSize: 12.5, color: S.cocoa400, fontFamily: S.sans, lineHeight: 1.6 }}>
        Data sources: FiveThirtyEight archive, VoteHub, Silver Bulletin, state pollster releases, Polymarket, Kalshi. Code &amp; full poll log on GitHub. Last model run: May 24, 2026, 6:00 ET.
      </div>
    </div>
  );
}

Object.assign(window, { ApprovalScreen, BallotScreen, SenateScreen, ForecastScreen, MethodologyScreen });
