# Election Oracle Design System

A professional, data-focused design system for election forecasting and polling analysis. Built from the [Election Models by Tre](https://github.com/Hijodeagua/Election-models-by-Tre) project, a sophisticated Python-based election modeling and forecasting system.

## Overview

Election Oracle is a comprehensive polling tracker and forecasting platform. This design system provides the visual language, components, and patterns necessary to build consistent, professional interfaces across multiple election-tracking surfaces including presidential approval, generic ballot polling, and Senate race forecasting.

## Design Principles

**Data-Driven**: Every visual element prioritizes clarity and accuracy. Charts, numbers, and trends are the heroes.

**Neutral & Factual**: Designed with explicit partisan visual cues (blue for Democratic, red for Republican) but maintains editorial neutrality in tone and framing.

**Light & Minimal**: Clean, spacious layouts with generous whitespace. No unnecessary ornamentation.

**Accessible**: High contrast, readable typography (minimum 16px for body text), keyboard navigation, semantic HTML.

**Responsive**: Mobile-first approach; works equally well on phones, tablets, and desktops.

## Content Fundamentals

### Tone & Voice
- **Factual and measured**: "Weighted polling average" not "prediction" or "forecast" (unless explicitly modeling).
- **Transparent about limitations**: Always include data source, number of polls, confidence intervals.
- **Audience-aware**: Written for educated, politically-engaged readers; assumes familiarity with polling terminology.
- **Avoid sensationalism**: Data speaks for itself. Avoid dramatic language.

### Casing & Mechanics
- **Sentence case** for UI labels: "Presidential approval tracker" not "PRESIDENTIAL APPROVAL TRACKER"
- **Title case** for proper nouns: "Silver Bulletin," "Polymarket," "NYT Vibes"
- **No emoji** in primary UI; occasional emoji in data tags (e.g., 📊) only in informal contexts
- **Numbers**: Always show one decimal place for percentages (45.2%), round margins to one decimal (D +3.4)
- **Directional indicators**: Use "D" and "R" consistently; "D +5.3" means Democratic +5.3 advantage

### Copywriting Examples
✅ "Weighted polling average of job-approval polls. This is a tracker of where polling stands today."
✅ "Congressional preference tracking with historical seat projection."
✅ "As of May 24, 2026 · 683 polls in window"
❌ "LIVE election forecast with AI-powered predictions!"
❌ "Democrats are winning by a landslide (probably)"

---

## Visual Foundations

### Color Palette

**Partisan Colors** (explicit, high contrast for clarity)
- **Democratic Blue**: `#2563eb` — primary action color, D candidate margins
- **Republican Red**: `#dc2626` — secondary action color, R candidate margins

**Neutral Palette** (Slate: 50–900)
- Used for UI chrome, typography, borders, backgrounds
- High contrast ratios (WCAG AAA)
- Warm undertones (not pure gray-blue)

**Semantic Colors**
- Status colors: Approve (blue), Disapprove (red), Neutral (slate-500)
- Chart confidence bands: `rgba(37, 99, 235, 0.15)` for D, `rgba(220, 38, 38, 0.15)` for R
- Interactive states: Hover (light slate), active (blue), disabled (low opacity)

### Typography

**Font Family**: System stack
```css
-apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif
```
Preferred: native OS fonts for speed and familiarity.

**Type Scales**:
- **Displays** (48px, 36px, 30px): Page titles, major section headings
- **Headings** (24px, 20px, 18px): Section headers, card titles
- **Body** (16px, 14px): Main reading copy
- **Caption** (12px): Metadata, helper text, source attribution

All text is sentence-case unless otherwise specified. Use **bold** (font-weight: 600–700) for emphasis and important numbers. Never use all-caps except for abbreviated UI labels (e.g., "NET APPROVAL").

**Line heights**: Tight (1.2) for headings, normal (1.5) for body, relaxed (1.75) for longer-form prose.

### Spacing & Layout

**4px base unit**:
- Spacing token: `--space-4` = 16px (one "unit")
- Padding: 16px (card interiors), 32px (page gutters)
- Gap: 16px (flex/grid children)
- Margins: 24px (section breaks), 8px (element grouping)

**Content width**: Max 1024px (`--max-width-lg`), centered with side padding.

**Card pattern**: 8px rounded corners, 1px slate-200 border, white background, subtle shadow (`0 1px 2px rgba(0,0,0,0.05)`). Used for: stats, race cards, chart containers.

### Backgrounds & Imagery

- **Primary background**: `#f8fafc` (slate-50) — light but not pure white
- **Surface background**: Pure white (`#ffffff`) — cards, modals, charts
- **Full-bleed imagery**: Not used in tracker UI; reserved for marketing/explanatory contexts
- **Charts**: Transparent background, no grid lines unless necessary (Recharts default)
- **Icons**: Not a core element; when needed, inherit color from text (e.g., blue icon for "Approve")

### Borders & Dividers

- **Card borders**: 1px `#e2e8f0` (slate-200)
- **Section dividers**: 1px `#e2e8f0` on top or bottom
- **No outer shadows on large cards**: Subtle box-shadow only on lifted elements (alerts, overlays)
- **Corner radius**: 8px standard (6px–12px acceptable per context)

### Hover & Interactive States

- **Buttons**: Darker shade on hover (dem-dark for primary, slate-300 for secondary), 150ms transition
- **Links**: Underline on hover; no color change (inherit from context)
- **Chips/toggles**: Border + background color change on selection; opacity 50% when disabled
- **Cards**: Subtle lift on hover (subtle shadow increase) for interactive elements only

### Animation & Motion

- **Standard duration**: 150ms (--duration-base)
- **Easing**: `ease-in-out` for all transitions
- **No infinite loops**: Animations should be purposeful, not decorative
- **Reduced motion**: Respect `prefers-reduced-motion: reduce` by removing all transitions

### Charts & Data Visualization

- **Approve line**: Democratic blue (#2563eb)
- **Disapprove line**: Republican red (#dc2626)
- **Confidence band**: Transparent fill, 15% opacity
- **Margins/seats**: Use same D-blue and R-red
- **No decorative gradients**: Flat colors for clarity
- **Tooltip**: Dark background (slate-900), white text, 6px padding
- **Axis labels**: 11px slate-600, no grid background

---

## Component Library

### Core Components

**Button** — Primary (blue), secondary (gray), ghost (text-only), danger (red)
```jsx
<Button variant="primary" size="md">Click me</Button>
```

**Card** — Bordered white container with padding
```jsx
<Card>Content here</Card>
```

**StatBox** — Stat display with label + large value
```jsx
<StatBox label="Approve" value="45.2" accent="text-dem" unit="%" />
```

**Badge** — Pill-shaped label for tags/categories
```jsx
<Badge variant="dem">Strong D</Badge>
```

**Chip** — Toggle-able small pill (used for vibes toggle, market odds)
```jsx
<Chip selected={showVibes} onClick={() => setShowVibes(!showVibes)}>
  NYT Vibes
</Chip>
```

### Composite Patterns

**Approval Tracker**: 3-column stat grid + daily trend chart + model comparison

**Generic Ballot Tracker**: Stat grid (D%, R%, advantage) + seat projection box

**Senate Race Card**: State name, candidate list, margin, toggle buttons (vibes, market odds)

---

## UI Kits

### Election Tracker (`ui_kits/election-tracker/`)

A fully interactive Next.js app showcasing:
- **Approval page**: Current approval/disapproval/net stats, daily trend chart, model comparison
- **Generic Ballot page**: D/R percentages, seat projection
- **Senate page**: Competitive race cards with toggles
- **Methodology page**: Explainer and transparency
- **Navigation**: Sticky header with 5-item nav

**Starting point**: Use `index.html` as the canonical view template. Components are in `screens.jsx` (re-usable) and `layout.jsx` (header/footer).

---

## Accessibility

- **Color contrast**: All text meets WCAG AAA (7:1 for body, 4.5:1 minimum)
- **Focus states**: 2px solid ring, offset 2px, blue focus color
- **Keyboard nav**: All interactive elements are keyboard-accessible
- **Semantic HTML**: Use `<button>` not `<div onclick>`, `<a>` for navigation
- **Alt text**: Charts have alt descriptions; logos have alt text
- **Font size**: Never smaller than 12px for reading copy (14px+ preferred)

---

## Tokens & CSS

All design tokens are stored as CSS custom properties in the `tokens/` directory:
- `colors.css` — Color palette
- `typography.css` — Font scales, weights, line heights
- `spacing.css` — Spacing, sizing, radii, shadows
- `transitions.css` — Durations, easing curves

Import them via the root `styles.css` file. Use in your CSS as `var(--color-dem)`, `var(--space-4)`, etc.

---

## File Structure

```
election-oracle-design-system/
├── styles.css                      # Root stylesheet (imports all tokens)
├── tokens/
│   ├── colors.css                  # Color palette
│   ├── typography.css              # Font scales
│   ├── spacing.css                 # Spacing, sizing, radii
│   └── transitions.css             # Animation tokens
├── components/
│   └── core/
│       ├── Button.jsx              # Button, Card, StatBox, Badge, Chip
│       ├── Button.d.ts             # Props interface
│       ├── Button.prompt.md        # Usage examples
│       └── components.card.html    # Visual specimen card
├── ui_kits/
│   └── election-tracker/
│       ├── index.html              # Main tracker UI demo
│       ├── screens.jsx             # Reusable screen components
│       └── layout.jsx              # Header, footer, layout
├── guidelines/
│   ├── colors.card.html            # Color palette card
│   ├── typography.card.html        # Type scale card
│   └── spacing.card.html           # Spacing card
├── assets/
│   └── logo-policy-peaches.svg     # Brand logo
└── README.md                       # This file
```

---

## Getting Started

### For Designers

1. Open the Design System tab in the Penpot/Figma interface
2. Browse the **Cards** section to see all tokens, components, and patterns
3. Reference this README for tone, spacing, and interaction patterns
4. Use the `ui_kits/election-tracker/` as a template for new surfaces

### For Developers

1. Import `styles.css` in your HTML or app:
   ```html
   <link rel="stylesheet" href="path/to/styles.css">
   ```
2. Use component exports from the bundle:
   ```jsx
   const { Button, Card, StatBox } = window.ElectionOracle;
   ```
3. Build custom components using CSS custom properties for colors, spacing, and type

### Design Decisions

**Why no custom fonts?** System fonts load instantly, look native on every device, and are accessible. Custom fonts add HTTP requests and can harm performance.

**Why slate for UI, blue/red for data?** Slate provides a neutral, professional palette. Blue and red are universally recognized partisan colors and have high contrast for accessibility.

**Why strict spacing scale?** It creates visual rhythm and makes layouts predictable. Always use increments of 4px (`--space-1` through `--space-16`).

**Why no gradient backgrounds?** They reduce contrast and can harm readability. Reserve gradients for decorative elements or charts.

---

## Contributing

To add or modify design system elements:

1. **New token**: Add CSS custom property to `tokens/` file, then import in `styles.css`
2. **New component**: Create `ComponentName.jsx` + `ComponentName.d.ts` + `ComponentName.prompt.md` in `components/`, then add a specimen card
3. **New pattern**: Document in a new `.card.html` file in `guidelines/`
4. **New UI kit**: Create a folder under `ui_kits/` with `index.html` and reusable component files

Always tag new `.html` cards with `<!-- @dsCard group="…" -->` as the first line so they appear in the Design System tab.

---

## References & Sources

This design system is derived from:
- **Election Models by Tre** (GitHub: Hijodeagua/Election-models-by-Tre) — The underlying Python forecasting engine that powers the tracker
- **Next.js Election Tracker UI** — Original interactive web frontend (TypeScript/React with Recharts)
- **Tailwind CSS** — Inspired the spacing and color naming conventions

---

## Version & Status

**Version**: 1.0 (May 2026)
**Status**: Foundation-ready. All core tokens, components, and UI patterns are stable.

---

Last updated: May 2026
