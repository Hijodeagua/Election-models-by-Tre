---
name: election-oracle-design
description: Use this skill to generate well-branded interfaces and assets for Election Oracle, a data-driven election forecasting platform. Contains essential design guidelines, tokens, typography, color palette, reusable components, and a complete UI kit for building polling trackers, forecast displays, and election analysis dashboards.
user-invocable: true
---

# Election Oracle Design Skill

Read the README.md file within this skill directory for a comprehensive overview of the design system, tone, and visual foundations.

## Quick Start

### For Designers Creating Visuals

1. **Colors**: Use `--color-dem` (#2563eb) for Democratic-leaning data/actions, `--color-rep` (#dc2626) for Republican-leaning. Use the slate palette (50–900) for UI chrome and neutral elements.

2. **Typography**: System fonts only. Body text is 16px minimum, headings are 24px+. Always include source attribution (e.g., "683 polls," "as of May 24, 2026").

3. **Spacing**: 16px is one unit. Use 16px padding inside cards, 32px page gutters, 16px gaps between flex/grid children.

4. **Components**: Import Button, Card, StatBox, Badge, and Chip from the bundle. Customize via CSS custom properties, never inline styles.

5. **Charts**: Use Recharts with blue for approve/Democrat, red for disapprove/Republican. Add confidence bands as subtle overlays (15% opacity fill).

### For Developers Building Production Code

1. **Link the stylesheet**:
   ```html
   <link rel="stylesheet" href="path/to/styles.css">
   ```

2. **Use component exports**:
   ```jsx
   const { Button, Card, StatBox } = window.ElectionOracle;
   ```

3. **Apply tokens in CSS**:
   ```css
   .my-button {
     background: var(--color-dem);
     padding: var(--space-4);
     border-radius: var(--radius-md);
     transition: var(--transition-bg);
   }
   ```

4. **Reference the UI kit** (`ui_kits/election-tracker/`) for patterns on:
   - Header/nav layout
   - Stat grids
   - Race cards with toggles
   - Chart containers

## Design Decisions

**Why no custom fonts?**
System fonts (Segoe UI, Roboto, SF Pro) load instantly, work on every device, and are accessible. No HTTP requests, no layout shift.

**Why blue + red for data?**
High contrast, universally recognized partisan colors, WCAG AAA compliant. Neutral slate palette for UI keeps data colors readable.

**Why strict spacing scale?**
4px base creates visual rhythm. `--space-4` (16px) is the default unit; larger gaps are multiples. Predictable, consistent across all surfaces.

**Why no decorative gradients or shadows?**
Clarity is paramount. Subtle borders and flat colors reduce visual clutter. Shadows are minimal and only on lifted elements (alerts, overlays).

## Common Patterns

### Approval Tracker
- 3-column stat grid (Approve, Disapprove, Net)
- Daily trend line chart with confidence band
- Model comparison toggle below

### Generic Ballot Tracker
- 3-column stat grid (D %, R %, Advantage)
- Seat projection box showing D and R seats
- Disclaimer: "Illustrative range based on current average"

### Senate Race Card
- State name + top 3 candidates with percentages
- Margin display (D +3.4, R +2.1, or Even)
- Toggle buttons: NYT Vibes (if available), market odds (Polymarket, Kalshi)

### Stat Box
```jsx
<StatBox 
  label="Approve" 
  value="45.2" 
  accent="text-dem"
  unit="%"
/>
```

### Chip Row (Toggles)
```jsx
<div style="display: flex; gap: 8px;">
  <Chip selected={showVibes} onClick={() => setShowVibes(!showVibes)}>
    NYT Vibes {showVibes ? 'on' : 'off'}
  </Chip>
  <Chip>Polymarket: D 58%</Chip>
</div>
```

## Tone & Copy Guidelines

**Always frame as a tracker, not a forecast** (unless explicitly modeling with probabilities).

✅ "Weighted polling average of job-approval polls"
✅ "Congressional preference tracking with historical seat projection"
✅ "As of May 24, 2026 · 683 polls in window"

❌ "LIVE election forecast with AI-powered predictions!"
❌ "Democrats are winning by a landslide"

**Include data source, poll count, and date** on every metric.

**Use sentence case** for UI labels, title case for proper nouns (Silver Bulletin, Polymarket, NYT).

**Avoid emoji** in primary UI (reserved for tags/data only).

## Component Props Reference

See `components/core/Button.d.ts` for full TypeScript definitions. Key components:

**Button**
```jsx
<Button 
  variant="primary|secondary|ghost|danger" 
  size="sm|md|lg"
  disabled={false}
  onClick={handler}
>
  Label
</Button>
```

**StatBox**
```jsx
<StatBox 
  label="Approve"       // Required
  value="45.2"          // Required
  accent="text-dem"     // Optional: text-dem, text-rep, text-slate-900
  unit="%"              // Optional
/>
```

**Badge**
```jsx
<Badge variant="default|dem|rep|neutral">Strong D</Badge>
```

**Chip**
```jsx
<Chip 
  selected={boolean}
  onClick={handler}
  disabled={false}
>
  Label
</Chip>
```

## What to Build With This System

- Polling trackers (approval, congressional, Senate races)
- Forecast dashboards with live charts
- Methodology explainers
- Model comparison tools
- Election coverage companion sites
- Campaign tracking boards

## Token Reference

All tokens are CSS custom properties. Reference them in your styles:

**Colors**: `--color-dem`, `--color-rep`, `--color-slate-50` through `--color-slate-900`, `--color-border-light`, `--color-text-primary`, etc.

**Spacing**: `--space-1` (4px) through `--space-16` (64px); commonly `--space-4` (16px), `--space-6` (24px), `--space-8` (32px)

**Typography**: `--font-size-base` (16px), `--font-size-2xl` (24px), `--font-weight-semibold` (600), `--line-height-normal` (1.5)

**Corners**: `--radius-md` (8px), `--radius-lg` (12px), `--radius-full` (9999px)

**Shadows**: `--shadow-sm` (subtle), `--shadow-base` (default), `--shadow-md` (raised)

**Transitions**: `--transition-color`, `--transition-bg`, `--duration-base` (150ms)

---

**Version**: 1.0 (May 2026)
**For questions**: Reference README.md or explore the UI kit at `ui_kits/election-tracker/index.html`
